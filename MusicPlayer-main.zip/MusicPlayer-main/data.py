
list_music = []
volume = 0.5
data = {
    "music": list_music,
    "volume": volume
}